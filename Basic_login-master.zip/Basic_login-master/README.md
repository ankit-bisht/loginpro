# LoginApp

This project was generated with [angular-cli](https://github.com/angular/angular-cli) version 1.0.0-beta.28.3.

##Working
The project uses ngx-facebook and implements login with facebook. Sessions are maintained for everyuser using local storage. 

## Further help

To get more help on the `angular-cli` use `ng help` or go check out the [Angular-CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
