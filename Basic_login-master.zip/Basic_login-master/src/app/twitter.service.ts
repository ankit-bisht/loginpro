//Ignore this file

import { Injectable } from '@angular/core';
declare var cb:any;

@Injectable()
export class TwitterService {
  constructor() { }
	
	abc(){
    console.log("Twitter Service");
  }
}
